wget https://www.python.org/ftp/python/2.7.12/Python-2.7.12.tar.xz
tar xvf Python-2.7.12.tar.xz
yum groupinstall "Development Tools"
./configure --pre=/usr
make && make altinstall

yum update
There was a problem importing one of the Python modules
required to run yum. The error leading to this problem was:

   No module named rpm


#!/usr/bin/python
vi $(which yum)

#!/usr/bin/python2.7
wget https://bootstrap.pypa.io/get-pip.py

Ok, so MySQL is running but is listening on the loopback interface (127.0.0.1) and not eth0 (your droplet's public IP address). Set secure.bind-address back to 127.0.0.1 so that MySQL doesn't listen on the public IP address once it is restarted and use $host = '127.0.0.1';. Does that work?

sudo netstat -plutn | grep -i sql
tcp 0 0 127.0.0.1:3306 0.0.0.0:* LISTEN 17375/mysqld


2) mysql> GRANT ALL ON mydbname.* TO root@'myipaddress'
-> IDENTIFIED BY 'mymysqlpassword';

It did'nt work, too.
